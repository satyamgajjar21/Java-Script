console.log("log");
console.warn("warn");
console.info("info");
console.error("err");
console.assert("err" != false);
console.assert("err" == true);

console.time("forloop")
for(let i=0; i<5;i++){
  console.log(233);
}
console.timeEnd("forloop")


console.time("whileloop")
for(let i=0; i<5;i++){
  console.log(233);
}
console.timeEnd("whileloop")