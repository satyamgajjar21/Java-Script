//Chapter 2PS
//P-1
let a1 = prompt("Enter your age");
if(a1<10){
  alert("Your age is less than 10");
}else if(a1>10 && a1<20){
  alert("Your age is in between 10 and 20");
}else{
  alert("Wrong input");
}
 
//P-2
let age = prompt("what is your age?")
switch(age){
  case '12':
    alert("Your age is 12");
    break;
      case '13':
    alert("Your age is 13");
    break;
      case '14':
    alert("Your age is 14");
    break;
      case '15':
    alert("Your age is 15");
    break;
      case '16':
    alert("Your age is 16");
    break;
  default: 
    alert("Age is invalid");
    break;
}

//P-6
let age = prompt("Enter age")
let a6 = age > 18? "Correct" : "Incorrect";
console.log(a6);
