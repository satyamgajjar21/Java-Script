document.getElementsByTagName("nav")[0].firstElementChild.style.color = "red"
document.getElementsByTagName("nav")[0].lastElementChild.style.color = "red"

//for each loop to make bg of all li cyan
Array.from(document.getElementsByTagName("li")).forEach((element) => {
  element.style.background = "cyan";
})