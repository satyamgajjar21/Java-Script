console.log("JS tutorial 3")

let b = "sat";
console.log(b)
const author = "Harry Potter";

{
  let b = "Gas"
  console.log(b)
}
