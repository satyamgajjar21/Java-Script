let a = prompt("Enter input")
a = Number.parseInt(a);

if(a<50){
  alert(" You can get loan at age " + a);
}
else if(a>50 && a < 75){
  alert("You can get less loan");
}
else {
  alert("The loan is given");
}


