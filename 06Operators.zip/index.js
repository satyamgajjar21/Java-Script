//Arithmetic Operators in JS
console.log("Arithmetic Operators------------------------------");
let a = 10;
let b = 4;
console.log("a+b = ", a + b);
console.log("a-b = ", a - b);
console.log("a*b = ", a * b);
console.log("a/b = ", a / b);
console.log("a**b = ", a ** b);
console.log("a%b = ", a % b);

console.log("a++", a++); //print= 10, value= 11
console.log(a);
console.log("++a", ++a); //print= 12, value= 12
console.log(a);
console.log("a--", a--); //print= 12, value= 11
console.log(a);
console.log("--a", --a); //print= 10, value= 10
console.log(a);

//Assignment Operators in JS
console.log("Assignment Operators------------------------------");
let a1 = 1;
a1 += 5;
a1 -= 5;
a1 *= 5;
a1 /= 5;
a1 **= 5;
a1 %= 5;
console.log(a1);

//Comparison Operators in JS
console.log("Comparison Operators------------------------------");
let c1 = 6;
let c2 = 7;
console.log("c1 == c2 is ", c1==c2);
console.log("c1 != c2 is ", c1!=c2);
console.log("c1 === c2 is ", c1===c2); //check 'type' too
console.log("c1 !== c2 is ", c1!==c2);
console.log("c1 > c2 is ", c1>c2);


//Logical Operators in JS
console.log("Logical Operators------------------------------");
let l1 = 2;
let l2 = 3;
 
//&&
//||
//!