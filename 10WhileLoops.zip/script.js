let n = prompt("Enter the value of n");
n = Number.parseInt(n);

let i = 0;
while(i<n){
  i = i + 1;
}
  alert("Ans is "+i);
