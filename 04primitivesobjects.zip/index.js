// nn bb ss u - primitive datatypes
let a = 112; //number
let b = null; //null
let c = false; //boolean
let d = BigInt(12); //bigint
let e = "Satyam"; //string
let f =  Symbol("Hey there"); //symbol
let g = undefined; //undefined
console.log(a,b,c,d,e,f,g);

//objects in JS - Non-Primitive datatypes
const user = {
  name : "satyam",
  surname : "gajjar",
  address : "waterloo",
  phone_number : 234324
}
console.log(user["name"]);