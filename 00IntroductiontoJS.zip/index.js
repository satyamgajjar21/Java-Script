console.log("Hello World")
 
function add(a,b){
  return a + b;
}
 
console.log(add(1,2));