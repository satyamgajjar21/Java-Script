console.log(document.body.firstChild);
console.log(document.body.lastChild);
let arr = Array.from(body.childNodes);
console.log(arr);