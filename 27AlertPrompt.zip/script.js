alert("Enter any number");
let a = prompt("Enter a here");
a = Number.parseInt(a);
alert("You have entered : " + a);

let write = confirm("Do you want to write it to the page?");
if (write) {
  document.write(a)
}
else {
  documemnt.write("Allow me to write.")
}