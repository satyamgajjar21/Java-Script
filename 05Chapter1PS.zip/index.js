//Chapter 1 
//Q1 - Create a variable of type string and try to add a number to it.
console.log("Q-1----------------------");
let a = "Satyam";
let b = 6;
let c = " ";
console.log(a+c+b);


//Q2 - Use type of operator to find the datatype of the string in last question
console.log("Q-2----------------------");
console.log(typeof (a+b));


//Q3 - Create a const obj in js. Can you change it to hold a number later(answer - no)
console.log("Q-3----------------------");
const items = {
   name : 'sat',
  surname: 'gajjar'
}
    //items = 34;
console.log(items["name"]);


//Q4 - try to add a new key to the const obj in q-3. 
console.log("Q-4----------------------");
items["name"] = "Shiv"
console.log(items);


//Q5 - write a js program to create a word meaning dictionary of 5 words
console.log("Q-5----------------------");
const dict = {
  appreciate: "hello word",
   yakka: "hard work",
   aver: "affirm",
}
console.log(dict);
console.log(dict.yakka);