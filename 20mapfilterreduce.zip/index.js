//Array map methods
let arr = [45, 65, 45]

let a = arr.map((value, index, array) => {
  console.log(value, index, array)
  return value + index;
})
console.log(a)
console.log("-----------------------");


//Array filter methods
let arr1 = [45, 65, 45, 09, 86, 76]

let a1 = arr1.filter((a1) => {
  return a1 < 10;
})
console.log(a1)

console.log("-----------------------");

//Array reduce methods
let arr3 = [45, 65, 45, 09, 86, 76]
const reduce_func = (h1, h2) => {
  return h1 + h2
}

let a3 = arr3.reduce(reduce_func);
console.log(a3);
