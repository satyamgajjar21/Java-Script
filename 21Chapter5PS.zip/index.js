//Create an array of numbers and take input from the user to add numbers to this array
// let array = [];
// let a = prompt("Enter number you want to push in array");
// a = Number.parseInt(a);

// array.push(a);
// console.log(array);

//Keep adding numbers in above array until 0 is reached.
// let array1 = [324, 234, 234, 234, 234];
// let a1;
// do {
//   a1 = prompt("Enter number you want to push in array");
//   a1 = Number.parseInt(a1);
//   array1.push(a1);
// } while (a1 != 0);
// console.log(array1)

//Filter for numbers divisible by 10 from a given array
// let arr = [12, 20, 30, 23, 32, 54, 56, 67, 78];
// let n = arr.filter((x) => {
//   return x % 10 == 0;
// })   
// console.log(n);

//Create an array of square of given numbers
// let arr = [1,2,3,4,5,53];
// let n = arr.map((x)=>{
//   return x*x;
// })
// console.log(n);