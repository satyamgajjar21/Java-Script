let marks = {
  satyam: 34,
  shivam: 45,
  shubhum: 40,
  mayur: 34
}

//P-1
for (let i = 0; i < Object.keys(marks).length; i++) {
  console.log("The marks of " + Object.keys(marks)[i] + " are " + marks[Object.keys(marks)[i]])
}

//P-2
for (let key in marks) {
  console.log(("The marks of " + key + " are " + marks[key]))
}

//P-3
let n1 = 43;
let i;
while (i != n1) {
  i = prompt("Enter no.")
}
console.log("Correct no.");

//P-4 
const mean = (a, b, c, d) => {
  return (a + b + c + d) / 4;
}
console.log(mean(1,2,3,4));