//Q-1
console.log("Har\"".length)


//Q-2
const sentence = 'The word in the sentence is hello!';
const word = 'car';
console.log(`The ${word} ${sentence.includes(word)? 'is' : 'is not'} in the sentence`)


//Q-3
console.log(word.toUpperCase())

//Q-4
let string1 = "Given data is 1000";
let finalString = Number.parseInt(string1.slice(13)); 
console.log(finalString);

//Q-5 //string is immutable
const name = "satyam"
replacedCharacter = name.replaceAt(1,"y");
console.log(replacedCharacter);
