//Basics
// let marks = [1,23,12,32,23,45, 'satyam'];
// console.log(marks);
// console.log(marks[0]);
// console.log(marks.length);
// console.log(typeof marks);


//Array methods
// let num = [1,2,3,4,5];
// let b = num.toString();

// console.log(b, typeof b);

// let c = num.join("-");
// console.log(c);

// let d = num.pop();
// console.log(d);

// let f = num.push();
// console.log(f);

// let e = num.shift();
// console.log(e);

// let g = num.unshift();
// console.log(g);

// sort method
// let compareAscending = (a,b)=> {
//   return a-b;
// }

// let compareDecending = (a,b)=> {
//   return b - a;
// }

// let num1 = [213,432,465,765,465];
// let num2 = [213,432,465,765,465];
// num1.sort(compareAscending);
// num2.sort(compareDecending);

// console.log(num1);
// console.log(num2);

//For each loop
// let n1 = [1,2,4,3,2,3];
// n1.forEach((element) => {
//   console.log( element);
// }) 

// //Array from
// let name = "Satyam";

// let arr = Array.from(name);
// console.log(name, typeof name);
// console.log(arr, typeof arr);

//for...of
let num = [1,2,4,3,2,3];
for(let i1 of num){
  console.log(i1);
}

//for...in
let num4 = [1,2,4,3,2,3];
for(let i1 in num4){
  console.log(num4[i1]);
}