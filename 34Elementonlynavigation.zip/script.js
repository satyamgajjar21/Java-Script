let b = document.body;
console.log("First child of b is: ", b.firstChild);
console.log("First element of b is: ", b.firstElementChild);


