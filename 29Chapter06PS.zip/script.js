//P-1
// let a = prompt("Enter your age");
// a= Number.parseInt(a);

// if(a<18){
//   alert("You cannot drive");
// }else{
//   alert("You can drive");
// }

//P-2
// let runAgain = true;
// while (runAgain) {

//   let a = prompt("Enter your age");
//   a = Number.parseInt(a);
//   if (a < 18) {
//     alert("You cannot drive");
//   } else if(a>18) {
//     alert("You can drive");
//   }else{
//     alert("You pressed cancel!");
//   }
//   runAgain = confirm("Do you want to play again");
// }

//P-3
// let number = prompt("Enter number: ");
// number = Number.parseInt(number);

// if(number > 4){
//   location.href = "https://google.com";
// }

//P-4
let color = prompt("Enter the page color: ");
document.body.style.background = color;